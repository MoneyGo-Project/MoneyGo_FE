// API Response Types
export interface ApiResponse<T = any> {
  data: T;
  message?: string;
  success: boolean;
}

// Auth Types
export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  email: string;
  password: string;
  name: string;
  phone: string;
}

export interface LoginResponse {
  token: string;
  expiresIn: number;
  userId: number;
  email: string;
  name: string;
  accountNumber: string;
}

export interface SignupResponse {
  userId: number;
  email: string;
  name: string;
  accountNumber: string;
  balance: number;
}

// Account Types
export interface AccountResponse {
  accountId: number;
  accountNumber: string;
  balance: number;
  status: string;
  createdAt: string;
}

export interface AccountOwnerResponse {
  accountNumber: string;
  ownerName: string;
}

// Transfer Types
export interface TransferRequest {
  toAccountNumber: string;
  amount: number;
  password: string;
  description?: string;
}

export interface TransferResponse {
  transactionId: number;
  fromAccount: string;
  toAccount: string;
  toAccountOwner: string;
  amount: number;
  description: string;
  status: string;
  createdAt: string;
  balanceAfter: number;
}

// Transaction Types
export interface TransactionResponse {
  transactionId: number;
  type: string;
  amount: number;
  fromAccount: string;
  toAccount: string;
  counterpartyName: string;
  description: string;
  status: string;
  createdAt: string;
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

// QR Payment Types
export interface QrGenerateRequest {
  amount: number;
  description?: string;
}

export interface QrGenerateResponse {
  qrPaymentId: number;
  qrCode: string;
  amount: number;
  description: string;
  status: string;
  expiresAt: string;
  createdAt: string;
}

export interface QrPayRequest {
  qrCode: string;
  password: string;
}

export interface QrPayResponse {
  qrPaymentId: number;
  transactionId: number;
  buyerAccount: string;
  sellerAccount: string;
  sellerName: string;
  amount: number;
  description: string;
  status: string;
  paidAt: string;
  balanceAfter: number;
}

// Notification Types
export interface NotificationResponse {
  notificationId: number;
  type: string;
  title: string;
  content: string;
  relatedTransactionId: number;
  amount: number;
  isRead: boolean;
  readAt: string | null;
  createdAt: string;
}
